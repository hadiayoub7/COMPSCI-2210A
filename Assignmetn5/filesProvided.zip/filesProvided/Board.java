import java.awt.*;
import javax.swing.*;

public class Board extends JComponent {

    public Board() {}

    public void paint(Graphics display) {
	    display.setColor(Color.lightGray);
    }
}
