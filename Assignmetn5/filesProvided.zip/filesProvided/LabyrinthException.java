public class LabyrinthException extends Exception {
  public LabyrinthException(String mssg) {
    super(mssg);
  }
}
